import React from 'react';
import { Card, Button, Badge } from './ui/ui';
import { Check } from 'lucide-react';

interface PricingCardProps {
  title: string;
  price: string;
  description: string;
  features: string[];
  popular?: boolean;
  testnet?: boolean;
}

export const PricingCard: React.FC<PricingCardProps> = ({
  title,
  price,
  description,
  features,
  popular = false,
  testnet = false,
}) => {
  return (
    <Card className={`relative ${popular ? 'ring-2 ring-primary shadow-glow' : ''}`}>
      {popular && (
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
          <Badge variant="testnet">Most Popular</Badge>
        </div>
      )}
      
      <div className="text-center mb-6">
        <h3 className="text-2xl font-bold text-foreground mb-2">{title}</h3>
        <div className="text-4xl font-bold text-gradient mb-2">{price}</div>
        <p className="text-muted-foreground">{description}</p>
        {testnet && (
          <Badge variant="testnet" className="mt-2">
            Free on Testnet
          </Badge>
        )}
      </div>

      <ul className="space-y-3 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center">
            <Check className="mr-3 h-4 w-4 text-primary flex-shrink-0" />
            <span className="text-muted-foreground">{feature}</span>
          </li>
        ))}
      </ul>

      <Button 
        variant={popular ? "hero" : "outline"} 
        className="w-full"
        disabled={testnet}
      >
        {testnet ? 'Available on Testnet' : 'Get Started'}
      </Button>
    </Card>
  );
};