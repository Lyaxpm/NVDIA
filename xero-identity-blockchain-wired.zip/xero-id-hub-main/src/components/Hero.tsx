import React from 'react';
import { Link } from 'react-router-dom';
import { Button, Badge } from './ui/ui';
import { ArrowRight, Shield, Zap } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen flex items-center bg-gradient-hero overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-primary-glow/10 rounded-full blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Badge */}
          <div className="mb-8">
            <Badge variant="testnet" className="text-sm px-4 py-2">
              <Shield className="mr-2 h-4 w-4" />
              UOMI Finney Testnet
            </Badge>
          </div>

          {/* Main headline */}
          <h1 className="text-4xl font-bold tracking-tight sm:text-6xl lg:text-7xl mb-6">
            <span className="text-gradient">Xero Identity</span>
            <br />
            <span className="text-foreground">Your On-Chain Self</span>
          </h1>

          {/* Subtitle */}
          <p className="mx-auto max-w-3xl text-lg text-muted-foreground sm:text-xl mb-8">
            Manage your public on-chain identity on UOMI Finney Testnet. 
            Create a decentralized profile that's permanent, verifiable, and truly yours.
          </p>

          {/* Features highlight */}
          <div className="flex flex-wrap justify-center gap-6 mb-12">
            <div className="flex items-center text-sm text-muted-foreground">
              <Shield className="mr-2 h-4 w-4 text-primary" />
              Permanent Storage
            </div>
            <div className="flex items-center text-sm text-muted-foreground">
              <Zap className="mr-2 h-4 w-4 text-primary" />
              Instant Updates
            </div>
            <div className="flex items-center text-sm text-muted-foreground">
              <Shield className="mr-2 h-4 w-4 text-primary" />
              Self-Sovereign
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to="/app">
              <Button variant="hero" size="xl" className="group">
                Launch App
                <ArrowRight className="ml-2 h-5 w-5 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
            <Link to="/docs">
              <Button variant="outline" size="xl">
                Read Documentation
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-3">
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient">100%</div>
              <div className="text-sm text-muted-foreground">Free & Open Source</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient">∞</div>
              <div className="text-sm text-muted-foreground">Permanent Storage</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gradient">0</div>
              <div className="text-sm text-muted-foreground">Gas Fees (Testnet)</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};