import React from 'react';
import { Alert, Button } from './ui/ui';
import { useAccount, useSwitchChain } from 'wagmi';
import { uomiFinney } from '@/lib/chain';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export const NetworkGate: React.FC = () => {
  const { chainId } = useAccount();
  const { switchChain, isPending } = useSwitchChain();
  const onWrong = chainId !== undefined && chainId !== uomiFinney.id;

  if (!onWrong) return null;

  return (
    <Alert variant="warning" className="mb-6">
      <AlertTriangle className="h-4 w-4 mr-2 inline" />
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <strong>Wrong Network</strong>
          <p className="text-sm mt-1">
            Please switch to UOMI Finney Testnet (Chain ID: 4386) to continue.
          </p>
        </div>
        <Button
          variant="secondary"
          size="sm"
          onClick={() => switchChain({ chainId: uomiFinney.id })}
          className="self-start sm:self-auto"
          disabled={isPending}
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          {isPending ? 'Switching…' : 'Switch Network'}
        </Button>
      </div>
    </Alert>
  );
};
