import React from 'react';
import { Card, Button, Skeleton, Badge } from './ui/ui';
import { useIdentity } from '@/contexts/IdentityContext';
import { useAccount } from 'wagmi';
import { RefreshCw, User, Mail, Globe, Twitter, ExternalLink } from 'lucide-react';

export const IdentityPreview: React.FC = () => {
  const { identity, loading, refreshIdentity } = useIdentity();
  const { isConnected } = useAccount();

  const handleRefresh = async () => {
    await refreshIdentity();
  };

  if (!isConnected) {
    return (
      <Card>
        <div className="text-center py-8 text-muted-foreground">
          <User className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>Connect wallet to view identity</p>
        </div>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Skeleton className="h-6 w-32" />
            <Skeleton className="h-8 w-20" />
          </div>
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-4 w-1/2" />
          <Skeleton className="h-4 w-2/3" />
        </div>
      </Card>
    );
  }

  if (!identity) {
    return (
      <Card>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-foreground">Your Identity</h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            disabled={loading}
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        
        <div className="text-center py-8 text-muted-foreground">
          <User className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p className="mb-2">No identity found yet</p>
          <p className="text-sm">Set your identity using the form to get started</p>
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Your Identity</h2>
        <div className="flex items-center gap-2">
          <Badge variant="testnet">Live on Testnet</Badge>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            disabled={loading}
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <User className="h-5 w-5 text-primary" />
          <div>
            <p className="font-medium text-foreground">{identity.name}</p>
            <p className="text-sm text-muted-foreground">Display Name</p>
          </div>
        </div>

        {identity.email && (
          <div className="flex items-center gap-3">
            <Mail className="h-5 w-5 text-primary" />
            <div className="min-w-0 flex-1">
              <p className="font-medium text-foreground break-all">{identity.email}</p>
              <p className="text-sm text-muted-foreground">Email Address</p>
            </div>
          </div>
        )}

        {identity.website && (
          <div className="flex items-center gap-3">
            <Globe className="h-5 w-5 text-primary" />
            <div className="min-w-0 flex-1">
              <a
                href={identity.website}
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium text-primary hover:text-primary-glow transition-colors break-all flex items-center gap-1"
              >
                {identity.website}
                <ExternalLink className="h-3 w-3 flex-shrink-0" />
              </a>
              <p className="text-sm text-muted-foreground">Website</p>
            </div>
          </div>
        )}

        {identity.twitter && (
          <div className="flex items-center gap-3">
            <Twitter className="h-5 w-5 text-primary" />
            <div className="min-w-0 flex-1">
              <a
                href={`https://twitter.com/${identity.twitter}`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-medium text-primary hover:text-primary-glow transition-colors break-all flex items-center gap-1"
              >
                @{identity.twitter}
                <ExternalLink className="h-3 w-3 flex-shrink-0" />
              </a>
              <p className="text-sm text-muted-foreground">Twitter</p>
            </div>
          </div>
        )}
      </div>

      <div className="mt-6 p-4 glass rounded-lg border border-card-border">
        <p className="text-xs text-muted-foreground">
          <strong>On-chain Address:</strong> {wallet.address}
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          This identity is permanently stored on the UOMI Finney Testnet blockchain.
        </p>
      </div>
    </Card>
  );
};