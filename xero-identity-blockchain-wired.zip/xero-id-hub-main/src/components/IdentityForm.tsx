import React, { useState, useEffect } from 'react';
import { Card, Input, Label, Button, Muted } from './ui/ui';
import { useAccount } from 'wagmi';
import { useIdentity } from '@/contexts/IdentityContext';
import { Save, Trash2, Info } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface IdentityFormData {
  name: string;
  email: string;
  website: string;
  twitter: string;
}

export const IdentityForm: React.FC = () => {
  const { isConnected } = useAccount();
  const { identity, loading, saveIdentity, clearIdentity } = useIdentity();
  const { toast } = useToast();

  const [formData, setFormData] = useState<IdentityFormData>({
    name: '',
    email: '',
    website: '',
    twitter: '',
  });

  const [errors, setErrors] = useState<Partial<IdentityFormData>>({});

  useEffect(() => {
    if (identity) {
      setFormData(identity);
    }
  }, [identity]);

  const validateForm = (): boolean => {
    const newErrors: Partial<IdentityFormData> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (formData.email && !formData.email.includes('@')) {
      newErrors.email = 'Please enter a valid email';
    }

    if (formData.website && !formData.website.startsWith('http')) {
      newErrors.website = 'Website must start with http:// or https://';
    }

    if (formData.twitter && formData.twitter.startsWith('@')) {
      newErrors.twitter = 'Enter username without @ symbol';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      await saveIdentity(formData);
      toast({
        title: "Identity Saved (Mock)",
        description: "Your identity has been saved to the blockchain.",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save identity. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleClear = () => {
    setFormData({ name: '', email: '', website: '', twitter: '' });
    clearIdentity();
    setErrors({});
    toast({
      title: "Identity Cleared",
      description: "Form has been reset.",
      variant: "default",
    });
  };

  const handleInputChange = (field: keyof IdentityFormData) => (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    setFormData(prev => ({ ...prev, [field]: e.target.value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const isDisabled = !wallet.connected || !wallet.networkCorrect;

  return (
    <Card>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Set Your Identity</h2>
        <div className="flex items-center text-muted-foreground">
          <Info className="h-4 w-4 mr-1" />
          <Muted className="text-xs">Data is public & permanent</Muted>
        </div>
      </div>

      {!wallet.connected && (
        <div className="text-center py-8 text-muted-foreground">
          <p>Connect your wallet to manage your identity</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="name">
            Name <span className="text-destructive">*</span>
          </Label>
          <Input
            id="name"
            type="text"
            value={formData.name}
            onChange={handleInputChange('name')}
            placeholder="Your full name"
            disabled={isDisabled}
            aria-invalid={!!errors.name}
            aria-describedby={errors.name ? 'name-error' : undefined}
          />
          {errors.name && (
            <p id="name-error" className="text-sm text-destructive mt-1">
              {errors.name}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={handleInputChange('email')}
            placeholder="your@email.com"
            disabled={isDisabled}
            aria-invalid={!!errors.email}
            aria-describedby={errors.email ? 'email-error' : undefined}
          />
          {errors.email && (
            <p id="email-error" className="text-sm text-destructive mt-1">
              {errors.email}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="website">Website</Label>
          <Input
            id="website"
            type="url"
            value={formData.website}
            onChange={handleInputChange('website')}
            placeholder="https://yourwebsite.com"
            disabled={isDisabled}
            aria-invalid={!!errors.website}
            aria-describedby={errors.website ? 'website-error' : undefined}
          />
          {errors.website && (
            <p id="website-error" className="text-sm text-destructive mt-1">
              {errors.website}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="twitter">Twitter</Label>
          <Input
            id="twitter"
            type="text"
            value={formData.twitter}
            onChange={handleInputChange('twitter')}
            placeholder="username (without @)"
            disabled={isDisabled}
            aria-invalid={!!errors.twitter}
            aria-describedby={errors.twitter ? 'twitter-error' : undefined}
          />
          {errors.twitter && (
            <p id="twitter-error" className="text-sm text-destructive mt-1">
              {errors.twitter}
            </p>
          )}
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            type="submit"
            variant="default"
            disabled={isDisabled || loading}
            className="flex-1"
          >
            <Save className="mr-2 h-4 w-4" />
            {loading ? 'Saving...' : 'Save Identity'}
          </Button>
          <Button
            type="button"
            variant="secondary"
            onClick={handleClear}
            disabled={isDisabled}
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Clear
          </Button>
        </div>
      </form>
    </Card>
  );
};