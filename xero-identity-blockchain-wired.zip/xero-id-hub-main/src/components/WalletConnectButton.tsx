import { ConnectKitButton } from 'connectkit';

export const WalletConnectButton = ({ variant = 'default', size = 'default', className = '' } : { variant?: 'default'|'hero'|'secondary', size?: 'default'|'lg'|'xl', className?: string }) => {
  return (
    <ConnectKitButton.Custom>
      {({ isConnected, isConnecting, show, truncatedAddress, ensName }) => (
        <button onClick={show} className={`${className} inline-flex items-center rounded-xl px-4 py-2 bg-white/10 hover:bg-white/20`}>
          {isConnecting ? 'Connecting…' : isConnected ? (ensName ?? truncatedAddress) : 'Connect Wallet'}
        </button>
      )}
    </ConnectKitButton.Custom>
  );
};
