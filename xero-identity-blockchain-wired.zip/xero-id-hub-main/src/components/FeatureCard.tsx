import React from 'react';
import { Card } from './ui/ui';
import { LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

export const FeatureCard: React.FC<FeatureCardProps> = ({ icon: Icon, title, description }) => {
  return (
    <Card className="text-center group hover:shadow-glow transition-all duration-300 hover:scale-105">
      <div className="mb-4 flex justify-center">
        <div className="rounded-lg bg-gradient-primary p-3 group-hover:shadow-glow transition-all duration-300">
          <Icon className="h-6 w-6 text-white" />
        </div>
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </Card>
  );
};