import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from './ui/ui';
import { WalletConnectButton } from './WalletConnectButton';
import { Menu, X, Zap } from 'lucide-react';

export const Navbar: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const isApp = location.pathname.startsWith('/app');

  const navigation = [
    { name: 'Features', href: '/#features' },
    { name: 'How It Works', href: '/#how-it-works' },
    { name: 'Pricing', href: '/#pricing' },
    { name: 'Docs', href: '/docs' },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full glass border-b border-card-border backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Zap className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold text-gradient">Xero Identity</span>
          </Link>

          {/* Desktop Navigation */}
          {!isApp && (
            <div className="hidden md:flex md:items-center md:space-x-8">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  {item.name}
                </a>
              ))}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center space-x-4">
            {isApp ? (
              <WalletConnectButton />
            ) : (
              <>
                <Link to="/app" className="hidden sm:block">
                  <Button variant="hero" size="sm">
                    Launch App
                  </Button>
                </Link>
                <Link to="/app" className="sm:hidden">
                  <Button variant="hero" size="sm">
                    App
                  </Button>
                </Link>
              </>
            )}

            {/* Mobile menu button */}
            {!isApp && (
              <button
                type="button"
                className="md:hidden p-2 rounded-md text-muted-foreground hover:text-foreground"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Toggle mobile menu"
              >
                {mobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation */}
        {!isApp && mobileMenuOpen && (
          <div className="md:hidden">
            <div className="space-y-1 px-2 pb-3 pt-2 border-t border-card-border">
              {navigation.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="block px-3 py-2 text-base font-medium text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </a>
              ))}
              <div className="px-3 py-2">
                <Link to="/app" onClick={() => setMobileMenuOpen(false)}>
                  <Button variant="hero" className="w-full">
                    Launch App
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};