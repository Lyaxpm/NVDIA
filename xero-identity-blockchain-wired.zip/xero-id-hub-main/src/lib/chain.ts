import type { Chain } from "viem";

export const uomiFinney = {
  id: 4386,
  name: "UOMI Finney Testnet",
  nativeCurrency: { name: "UOMI", symbol: "UOMI", decimals: 18 },
  rpcUrls: { default: { http: [import.meta.env.VITE_RPC_URL || "https://finney.uomi.ai"] } },
  blockExplorers: { default: { name: "UOMI Scan", url: "https://scan.uomi.ai" } },
  testnet: true,
} as const satisfies Chain;
