export const IDENTITY_CONTRACT: `0x${string}` = (import.meta.env.VITE_IDENTITY_CONTRACT as `0x${string}`)
  ?? "0x021f617FadD09854573e7D70D8F0f6f57de3602b";
export const RPC_URL = import.meta.env.VITE_RPC_URL || "https://finney.uomi.ai";
