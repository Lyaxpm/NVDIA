import { createConfig, http } from "wagmi";
import { getDefaultConfig } from "connectkit";
import { uomiFinney } from "@/lib/chain";

export const wagmiConfig = createConfig(
  getDefaultConfig({
    appName: "Xero Identity",
    chains: [uomiFinney],
    transports: {
      [uomiFinney.id]: http(uomiFinney.rpcUrls.default.http[0]),
    },
  })
);
