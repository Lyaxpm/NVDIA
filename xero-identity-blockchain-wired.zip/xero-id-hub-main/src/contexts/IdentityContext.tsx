import React, { createContext, useContext, useState, useCallback } from 'react';
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt } from 'wagmi';
import { IDENTITY_ABI, type IdentityTuple } from '@/lib/identity.abi';
import { IDENTITY_CONTRACT } from '@/lib/env';

interface IdentityData {
  name: string;
  email: string;
  website: string;
  twitter: string;
}

interface IdentityContextType {
  identity: IdentityData | null;
  loading: boolean;
  saveIdentity: (data: IdentityData) => Promise<void>;
  clearIdentity: () => void;
  refreshIdentity: () => Promise<void>;
}

const IdentityContext = createContext<IdentityContextType | undefined>(undefined);
export const useIdentity = () => {
  const ctx = useContext(IdentityContext);
  if (!ctx) throw new Error('useIdentity must be used within an IdentityProvider');
  return ctx;
};

export const IdentityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { address, isConnected } = useAccount();
  const [loading, setLoading] = useState(false);
  const [identity, setIdentity] = useState<IdentityData | null>(null);

  // read current identity
  const read = useReadContract({
    abi: IDENTITY_ABI,
    address: IDENTITY_CONTRACT,
    functionName: 'getIdentity',
    args: [address ?? '0x0000000000000000000000000000000000000000'],
    query: { enabled: !!address }
  });

  React.useEffect(() => {
    if (read.data) {
      const [name, email, website, twitter] = (read.data as IdentityTuple);
      const hasAny = [name, email, website, twitter].some(Boolean);
      setIdentity(hasAny ? { name, email, website, twitter } : null);
    }
  }, [read.data]);

  const { writeContractAsync } = useWriteContract();

  const saveIdentity = useCallback(async (data: IdentityData) => {
    if (!isConnected) throw new Error('Wallet not connected');
    setLoading(true);
    try {
      const txHash = await writeContractAsync({
        abi: IDENTITY_ABI,
        address: IDENTITY_CONTRACT,
        functionName: 'setIdentity',
        args: [data.name, data.email, data.website, data.twitter]
      });
      // Optimistically set, then refetch
      setIdentity(data);
      await read.refetch();
    } finally {
      setLoading(false);
    }
  }, [isConnected, writeContractAsync, read]);

  const clearIdentity = useCallback(() => {
    setIdentity(null);
  }, []);

  const refreshIdentity = useCallback(async () => {
    setLoading(true)
    try:
        await read.refetch()
    finally:
        setLoading(false)
  }, [read]);

  return (
    <IdentityContext.Provider value={{ identity, loading, saveIdentity, clearIdentity, refreshIdentity }}>
      {children}
    </IdentityContext.Provider>
  );
};
