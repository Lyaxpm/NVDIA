import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, Badge, Alert } from '@/components/ui/ui';
import { Book, ChevronRight, AlertTriangle, Info, Code, Zap, Shield } from 'lucide-react';

export const Docs: React.FC = () => {
  const [activeSection, setActiveSection] = useState('getting-started');

  const sections = [
    { id: 'getting-started', title: 'Getting Started', icon: Zap },
    { id: 'testnet', title: 'Testnet Guide', icon: Shield },
    { id: 'connect-wallet', title: 'Connect Wallet', icon: Book },
    { id: 'data-format', title: 'Data Format', icon: Code },
    { id: 'faq', title: 'Technical FAQ', icon: Info }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'getting-started':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gradient mb-4">Getting Started with Xero Identity</h1>
              <p className="text-lg text-muted-foreground mb-6">
                Welcome to Xero Identity! This guide will help you get started with managing your 
                decentralized identity on the UOMI Finney Testnet.
              </p>
            </div>

            <Alert>
              <Info className="h-4 w-4" />
              <div>
                <strong>Testnet Environment</strong>
                <p className="mt-1">
                  You're currently using the testnet version. All transactions are free and for testing purposes only.
                </p>
              </div>
            </Alert>

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">What is Xero Identity?</h2>
              <p className="text-muted-foreground mb-4">
                Xero Identity is a decentralized identity management system that allows you to create, 
                manage, and share your public profile information on the blockchain. Your identity data 
                is permanently stored and verifiable by anyone.
              </p>
              
              <h3 className="text-lg font-medium text-foreground mb-2">Key Features:</h3>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Permanent on-chain storage</li>
                <li>Self-sovereign identity control</li>
                <li>Cross-platform compatibility</li>
                <li>Instant updates and verification</li>
                <li>No central authority required</li>
              </ul>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="p-4">
                <h3 className="font-semibold text-foreground mb-2">Quick Start</h3>
                <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
                  <li>Connect your Web3 wallet</li>
                  <li>Switch to UOMI Finney Testnet</li>
                  <li>Fill in your identity information</li>
                  <li>Save to blockchain</li>
                </ol>
              </Card>
              <Card className="p-4">
                <h3 className="font-semibold text-foreground mb-2">Requirements</h3>
                <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                  <li>Web3 wallet (MetaMask, etc.)</li>
                  <li>UOMI Finney Testnet access</li>
                  <li>Modern web browser</li>
                  <li>Internet connection</li>
                </ul>
              </Card>
            </div>
          </div>
        );

      case 'testnet':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gradient mb-4">UOMI Finney Testnet</h1>
              <p className="text-lg text-muted-foreground mb-6">
                Learn how to set up and use the UOMI Finney Testnet for testing Xero Identity.
              </p>
            </div>

            <Alert variant="warning">
              <AlertTriangle className="h-4 w-4" />
              <div>
                <strong>Testnet Notice</strong>
                <p className="mt-1">
                  This is a test network. Do not use real funds or sensitive information.
                </p>
              </div>
            </Alert>

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Network Configuration</h2>
              <Card className="p-4 font-mono text-sm">
                <div className="space-y-2">
                  <div><strong>Network Name:</strong> UOMI Finney Testnet</div>
                  <div><strong>Chain ID:</strong> 4386</div>
                  <div><strong>Currency:</strong> UOMI</div>
                  <div><strong>RPC URL:</strong> https://testnet-rpc.uomi.network</div>
                  <div><strong>Explorer:</strong> https://testnet-explorer.uomi.network</div>
                </div>
              </Card>
            </div>

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Adding to MetaMask</h2>
              <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
                <li>Open MetaMask and click on the network dropdown</li>
                <li>Select "Add Network" or "Custom RPC"</li>
                <li>Enter the network configuration details above</li>
                <li>Click "Save" to add the network</li>
                <li>Switch to the UOMI Finney Testnet</li>
              </ol>
            </div>

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Getting Test Tokens</h2>
              <p className="text-muted-foreground mb-4">
                You'll need test UOMI tokens to pay for transaction fees. Visit the faucet to get free test tokens:
              </p>
              <Card className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <strong className="text-foreground">UOMI Testnet Faucet</strong>
                    <p className="text-sm text-muted-foreground">Get free test tokens for development</p>
                  </div>
                  <Badge variant="outline">External Link</Badge>
                </div>
              </Card>
            </div>
          </div>
        );

      case 'connect-wallet':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gradient mb-4">Connecting Your Wallet</h1>
              <p className="text-lg text-muted-foreground mb-6">
                Step-by-step guide to connect your Web3 wallet to Xero Identity.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Supported Wallets</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card className="p-4">
                  <h3 className="font-semibold text-foreground mb-2">MetaMask</h3>
                  <p className="text-sm text-muted-foreground">
                    The most popular Web3 wallet with full support for custom networks.
                  </p>
                </Card>
                <Card className="p-4">
                  <h3 className="font-semibold text-foreground mb-2">WalletConnect</h3>
                  <p className="text-sm text-muted-foreground">
                    Connect using mobile wallets that support WalletConnect protocol.
                  </p>
                </Card>
              </div>
            </div>

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Connection Process</h2>
              <ol className="list-decimal list-inside space-y-3 text-muted-foreground">
                <li>
                  <strong className="text-foreground">Click "Connect Wallet"</strong>
                  <p className="ml-4 text-sm">Look for the Connect Wallet button in the app header.</p>
                </li>
                <li>
                  <strong className="text-foreground">Choose Your Wallet</strong>
                  <p className="ml-4 text-sm">Select your preferred wallet from the available options.</p>
                </li>
                <li>
                  <strong className="text-foreground">Approve Connection</strong>
                  <p className="ml-4 text-sm">Your wallet will ask for permission to connect to the dApp.</p>
                </li>
                <li>
                  <strong className="text-foreground">Switch Network</strong>
                  <p className="ml-4 text-sm">If prompted, switch to UOMI Finney Testnet.</p>
                </li>
              </ol>
            </div>

            <Alert>
              <Info className="h-4 w-4" />
              <div>
                <strong>Connection Issues?</strong>
                <p className="mt-1">
                  Make sure you have the UOMI Finney Testnet added to your wallet and that 
                  you're using a supported browser.
                </p>
              </div>
            </Alert>
          </div>
        );

      case 'data-format':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gradient mb-4">Identity Data Format</h1>
              <p className="text-lg text-muted-foreground mb-6">
                Understanding the structure and format of identity data stored on-chain.
              </p>
            </div>

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Data Structure</h2>
              <p className="text-muted-foreground mb-4">
                Your identity data is stored as a JSON object on the blockchain with the following structure:
              </p>
              
              <Card className="p-4">
                <pre className="text-sm overflow-x-auto">
                  <code>{`{
  "name": "string",      // Required: Your display name
  "email": "string",     // Optional: Email address
  "website": "string",   // Optional: Website URL
  "twitter": "string",   // Optional: Twitter username (no @)
  "timestamp": "number", // Automatic: Last update time
  "version": "string"    // Automatic: Schema version
}`}</code>
                </pre>
              </Card>
            </div>

            <div>
              <h2 className="text-2xl font-semibold text-foreground mb-4">Field Validation</h2>
              <div className="space-y-4">
                <Card className="p-4">
                  <h3 className="font-semibold text-foreground mb-2">Name (Required)</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Must not be empty</li>
                    <li>• Maximum 100 characters</li>
                    <li>• Can contain letters, numbers, spaces, and common symbols</li>
                  </ul>
                </Card>

                <Card className="p-4">
                  <h3 className="font-semibold text-foreground mb-2">Email (Optional)</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Must be valid email format if provided</li>
                    <li>• Maximum 320 characters</li>
                    <li>• Example: user@example.com</li>
                  </ul>
                </Card>

                <Card className="p-4">
                  <h3 className="font-semibold text-foreground mb-2">Website (Optional)</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Must start with http:// or https://</li>
                    <li>• Must be valid URL format</li>
                    <li>• Example: https://example.com</li>
                  </ul>
                </Card>

                <Card className="p-4">
                  <h3 className="font-semibold text-foreground mb-2">Twitter (Optional)</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Username without @ symbol</li>
                    <li>• Must follow Twitter username rules</li>
                    <li>• Example: username (not @username)</li>
                  </ul>
                </Card>
              </div>
            </div>

            <Alert variant="warning">
              <AlertTriangle className="h-4 w-4" />
              <div>
                <strong>Data Privacy Notice</strong>
                <p className="mt-1">
                  All data stored on-chain is public and permanent. Only include information 
                  you're comfortable sharing publicly.
                </p>
              </div>
            </Alert>
          </div>
        );

      case 'faq':
        return (
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-gradient mb-4">Technical FAQ</h1>
              <p className="text-lg text-muted-foreground mb-6">
                Common technical questions and detailed answers.
              </p>
            </div>

            <div className="space-y-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  How is data stored on the blockchain?
                </h3>
                <p className="text-muted-foreground">
                  Your identity data is stored as part of a smart contract transaction. When you update 
                  your identity, a new transaction is created that includes your data in a structured format. 
                  This ensures permanent, immutable storage that can be verified by anyone.
                </p>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  Can I delete my identity data?
                </h3>
                <p className="text-muted-foreground">
                  Due to the permanent nature of blockchain, you cannot completely delete data once it's 
                  stored. However, you can update your identity to empty values effectively "clearing" 
                  your public profile. The transaction history will remain but your current identity 
                  will appear as cleared.
                </p>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  What are gas fees and costs?
                </h3>
                <p className="text-muted-foreground">
                  On the testnet, all transactions are free. On mainnet, you'll pay small gas fees 
                  for each identity update transaction. These fees go to network validators and are 
                  typically very low. The Xero Identity service itself is free to use.
                </p>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  How do other apps access my identity?
                </h3>
                <p className="text-muted-foreground">
                  Other dApps can read your identity data directly from the blockchain using your wallet 
                  address. They can query the smart contract to retrieve your latest identity information. 
                  This enables seamless integration across different platforms and services.
                </p>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  Is there an API available?
                </h3>
                <p className="text-muted-foreground">
                  Yes! Developers can integrate with Xero Identity using our smart contract ABI or 
                  our REST API endpoints. Documentation for developers includes code examples, 
                  integration guides, and best practices for building identity-aware applications.
                </p>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-foreground mb-3">
                  What happens if I lose access to my wallet?
                </h3>
                <p className="text-muted-foreground">
                  Your identity is tied to your wallet address. If you lose access to your wallet, 
                  you won't be able to update your identity data. However, the existing data remains 
                  publicly accessible. Always keep secure backups of your wallet recovery phrases.
                </p>
              </Card>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-4 sticky top-24">
              <h2 className="text-lg font-semibold text-foreground mb-4">Documentation</h2>
              <nav className="space-y-1">
                {sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 text-sm rounded-md transition-colors text-left ${
                      activeSection === section.id
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:text-foreground hover:bg-accent'
                    }`}
                  >
                    <div className="flex items-center">
                      <section.icon className="mr-2 h-4 w-4" />
                      {section.title}
                    </div>
                    <ChevronRight className="h-3 w-3" />
                  </button>
                ))}
              </nav>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <Card className="p-8">
              {renderContent()}
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};