import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { NetworkGate } from '@/components/NetworkGate';
import { IdentityForm } from '@/components/IdentityForm';
import { IdentityPreview } from '@/components/IdentityPreview';
import { Card, Button, Alert, Table, TableHeader, TableBody, TableRow, TableHead, TableCell, Badge } from '@/components/ui/ui';
import { useAccount } from 'wagmi';
import { Book, Activity, Info, ExternalLink } from 'lucide-react';

export const App: React.FC = () => {
  const { isConnected } = useAccount();
  const [activeTab, setActiveTab] = useState<'identity' | 'activity'>('identity');

  const mockActivities = [
    {
      id: 1,
      action: 'Identity Created',
      timestamp: '2024-01-15 14:30:25',
      status: 'Success',
      txHash: '0xabc123...'
    },
    {
      id: 2,
      action: 'Profile Updated',
      timestamp: '2024-01-14 09:15:42',
      status: 'Success',
      txHash: '0xdef456...'
    },
    {
      id: 3,
      action: 'Twitter Updated',
      timestamp: '2024-01-13 16:22:10',
      status: 'Success',
      txHash: '0x789xyz...'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gradient mb-2">Identity Manager</h1>
          <p className="text-muted-foreground">
            Manage your decentralized identity on UOMI Finney Testnet
          </p>
        </div>

        {/* Intro Card */}
        <Alert className="mb-6">
          <Info className="h-4 w-4 mr-2 inline" />
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <strong>Welcome to Xero Identity Testnet</strong>
              <p className="text-sm mt-1">
                You're using the testnet version. All transactions are free and for testing purposes only.
              </p>
            </div>
            <Button variant="outline" size="sm" className="self-start sm:self-auto">
              <Book className="mr-2 h-4 w-4" />
              View Docs
              <ExternalLink className="ml-1 h-3 w-3" />
            </Button>
          </div>
        </Alert>

        {/* Network Gate */}
        <NetworkGate />

        {/* Tab Navigation */}
        <div className="mb-6">
          <div className="flex space-x-1 glass rounded-lg p-1 w-fit">
            <button
              onClick={() => setActiveTab('identity')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                activeTab === 'identity'
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Identity
            </button>
            <button
              onClick={() => setActiveTab('activity')}
              className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${
                activeTab === 'activity'
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              <Activity className="mr-2 h-4 w-4 inline" />
              Activity
            </button>
          </div>
        </div>

        {/* Main Content */}
        {activeTab === 'identity' ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Identity Form */}
            <div>
              <IdentityForm />
            </div>

            {/* Identity Preview */}
            <div>
              <IdentityPreview />
            </div>
          </div>
        ) : (
          /* Activity Tab */
          <Card>
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-foreground">Transaction History</h2>
              <Badge variant="secondary">{isConnected ? mockActivities.length : 0} transactions</Badge>
            </div>

            {!isConnected ? (
              <div className="text-center py-8 text-muted-foreground">
                <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Connect your wallet to view transaction history</p>
              </div>
            ) : mockActivities.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p className="mb-2">No transactions yet</p>
                <p className="text-sm">Your identity transactions will appear here</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Action</TableHead>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Transaction</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockActivities.map((activity) => (
                    <TableRow key={activity.id}>
                      <TableCell className="font-medium">{activity.action}</TableCell>
                      <TableCell className="text-muted-foreground">{activity.timestamp}</TableCell>
                      <TableCell>
                        <Badge variant="success">{activity.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <a
                          href="#"
                          className="text-primary hover:text-primary-glow transition-colors flex items-center gap-1"
                        >
                          {activity.txHash}
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </Card>
        )}
      </div>
    </div>
  );
};