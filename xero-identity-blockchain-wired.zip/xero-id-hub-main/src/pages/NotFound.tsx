import { Link, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Button, Card } from "@/components/ui/ui";
import { Home, ArrowLeft, Search } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <Card className="text-center max-w-md w-full p-8">
        <div className="mb-6">
          <Search className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-50" />
          <h1 className="text-6xl font-bold text-gradient mb-2">404</h1>
          <p className="text-xl text-foreground mb-2">Page Not Found</p>
          <p className="text-muted-foreground">
            The page you're looking for doesn't exist or has been moved.
          </p>
        </div>
        
        <div className="space-y-3">
          <Link to="/" className="block">
            <Button variant="hero" className="w-full">
              <Home className="mr-2 h-4 w-4" />
              Go to Homepage
            </Button>
          </Link>
          <Link to="/app" className="block">
            <Button variant="outline" className="w-full">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Launch App
            </Button>
          </Link>
        </div>
      </Card>
    </div>
  );
};

export default NotFound;
