import React from 'react';
import { Link } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Hero } from '@/components/Hero';
import { FeatureCard } from '@/components/FeatureCard';
import { FaqItem } from '@/components/FaqItem';
import { PricingCard } from '@/components/PricingCard';
import { Button, SectionTitle, Card, Badge } from '@/components/ui/ui';
import { 
  Shield, 
  Zap, 
  Globe, 
  Users, 
  Lock, 
  Smartphone,
  ArrowRight,
  Star,
  CheckCircle
} from 'lucide-react';

export const Landing: React.FC = () => {
  const features = [
    {
      icon: Shield,
      title: "Permanent Storage",
      description: "Your identity data is permanently stored on the blockchain, ensuring it's always accessible and verifiable."
    },
    {
      icon: Zap,
      title: "Instant Updates",
      description: "Update your identity information instantly with blockchain transactions, visible to everyone immediately."
    },
    {
      icon: Globe,
      title: "Global Access",
      description: "Access your identity from anywhere in the world. No central authority can restrict or modify your data."
    },
    {
      icon: Users,
      title: "Interoperable",
      description: "Your identity works across all dApps and services that support the protocol standard."
    },
    {
      icon: Lock,
      title: "Self-Sovereign",
      description: "You own and control your identity completely. No third parties can access or modify your data."
    },
    {
      icon: Smartphone,
      title: "Mobile Ready",
      description: "Fully responsive design that works seamlessly on all devices and screen sizes."
    }
  ];

  const steps = [
    {
      step: "01",
      title: "Connect Wallet",
      description: "Connect your Web3 wallet to the UOMI Finney Testnet to get started."
    },
    {
      step: "02", 
      title: "Set Your Identity",
      description: "Fill in your profile information including name, email, website, and social links."
    },
    {
      step: "03",
      title: "Share & Verify",
      description: "Your identity is now permanently stored on-chain and can be verified by anyone."
    }
  ];

  const testimonials = [
    {
      name: "Alex Chen",
      role: "DeFi Developer",
      content: "Xero Identity makes it so easy to have a verified presence across all the dApps I use. Game changer!",
      avatar: "AC"
    },
    {
      name: "Sarah Kim",
      role: "NFT Artist",
      content: "Having a permanent, verifiable identity on-chain has helped me build trust with collectors.",
      avatar: "SK"
    },
    {
      name: "Marcus Johnson",
      role: "DAO Contributor",
      content: "The seamless integration across different platforms is exactly what the Web3 space needed.",
      avatar: "MJ"
    }
  ];

  const faqs = [
    {
      question: "What is Xero Identity?",
      answer: "Xero Identity is a decentralized identity management system that allows you to create and manage your public profile on the blockchain. Your identity data is permanently stored and verifiable."
    },
    {
      question: "Is my data safe and private?",
      answer: "The data you store is public by design - it's meant to be your public identity. Only store information you're comfortable sharing publicly. You have complete control over what you share."
    },
    {
      question: "What is the UOMI Finney Testnet?",
      answer: "UOMI Finney Testnet is a blockchain testnet where you can experiment with blockchain applications without real money. It's perfect for testing and development."
    },
    {
      question: "Are there any fees?",
      answer: "On the testnet, everything is free! When we launch on mainnet, there will be small gas fees for transactions, but the service itself remains free to use."
    },
    {
      question: "Can I change my identity information?",
      answer: "Yes, you can update your identity information at any time. Each update creates a new transaction on the blockchain, maintaining a full history."
    },
    {
      question: "How is this different from traditional profiles?",
      answer: "Unlike traditional profiles stored on centralized servers, your Xero Identity is stored on the blockchain, making it permanent, censorship-resistant, and truly owned by you."
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      {/* Hero Section */}
      <Hero />

      {/* Features Section */}
      <section id="features" className="py-24 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <SectionTitle>Why Choose Xero Identity?</SectionTitle>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Built for the future of decentralized identity management with security, 
              permanence, and user control at its core.
            </p>
          </div>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <FeatureCard
                key={index}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
              />
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <SectionTitle>How It Works</SectionTitle>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Get started with your decentralized identity in three simple steps.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {steps.map((step, index) => (
              <Card key={index} className="text-center relative">
                <div className="text-4xl font-bold text-gradient mb-4">{step.step}</div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
                {index < steps.length - 1 && (
                  <ArrowRight className="hidden md:block absolute -right-4 top-1/2 transform -translate-y-1/2 h-6 w-6 text-primary" />
                )}
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Screenshots/Preview Section */}
      <section className="py-24 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <SectionTitle>See It In Action</SectionTitle>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Clean, intuitive interface designed for the best user experience.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Intuitive Identity Management
              </h3>
              <p className="text-lg text-muted-foreground mb-6">
                Our streamlined interface makes it easy to manage your on-chain identity. 
                Update your information, view your profile, and track activity all in one place.
              </p>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <CheckCircle className="mr-3 h-5 w-5 text-primary" />
                  <span className="text-muted-foreground">Real-time identity preview</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="mr-3 h-5 w-5 text-primary" />
                  <span className="text-muted-foreground">Form validation and error handling</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="mr-3 h-5 w-5 text-primary" />
                  <span className="text-muted-foreground">Activity tracking and history</span>
                </li>
              </ul>
            </div>
            <Card className="p-8 bg-gradient-card">
              <div className="text-center text-muted-foreground">
                <div className="w-full h-64 bg-muted/20 rounded-lg flex items-center justify-center mb-4">
                  <p>App Screenshot Placeholder</p>
                </div>
                <p className="text-sm">Interactive dApp Interface Preview</p>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <SectionTitle>What Our Users Say</SectionTitle>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Join thousands of users building their decentralized identity.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-primary fill-current" />
                  ))}
                </div>
                <p className="text-muted-foreground mb-4">"{testimonial.content}"</p>
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded-full bg-gradient-primary flex items-center justify-center text-white font-medium text-sm mr-3">
                    {testimonial.avatar}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <SectionTitle>Simple, Transparent Pricing</SectionTitle>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Start for free on testnet. Pay only for what you use on mainnet.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3 max-w-5xl mx-auto">
            <PricingCard
              title="Testnet"
              price="Free"
              description="Perfect for testing and development"
              testnet={true}
              features={[
                "Unlimited identity updates",
                "Full feature access",
                "Community support",
                "No gas fees",
                "Perfect for testing"
              ]}
            />
            <PricingCard
              title="Mainnet Basic"
              price="Gas Only"
              description="Pay only blockchain transaction fees"
              popular={true}
              features={[
                "Permanent identity storage",
                "Unlimited updates",
                "Full feature access",
                "Priority support",
                "Cross-dApp compatibility"
              ]}
            />
            <PricingCard
              title="Enterprise"
              price="Custom"
              description="Custom solutions for organizations"
              features={[
                "Bulk identity management",
                "Custom integrations",
                "Dedicated support",
                "SLA guarantees",
                "Advanced analytics"
              ]}
            />
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-muted/30">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <SectionTitle>Frequently Asked Questions</SectionTitle>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
              Everything you need to know about Xero Identity.
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <FaqItem
                key={index}
                question={faq.question}
                answer={faq.answer}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-background">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
          <div className="glass rounded-2xl p-8 md:p-12 border border-card-border">
            <Badge variant="testnet" className="mb-6">
              Get Started Today
            </Badge>
            <h2 className="text-3xl font-bold text-gradient mb-4">
              Ready to Own Your Identity?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Join the decentralized identity revolution and take control of your online presence.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/app">
                <Button variant="hero" size="xl">
                  Launch App Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/docs">
                <Button variant="outline" size="xl">
                  Read Documentation
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};