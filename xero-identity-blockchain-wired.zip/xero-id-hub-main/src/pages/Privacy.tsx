import React from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Card, Alert } from '@/components/ui/ui';
import { Shield } from 'lucide-react';

export const Privacy: React.FC = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
        <Card className="p-8">
          <div className="prose prose-invert max-w-none">
            <h1 className="text-3xl font-bold text-gradient mb-8">Privacy Policy</h1>
            
            <p className="text-muted-foreground mb-6">
              <strong>Last updated:</strong> January 2024
            </p>

            <Alert className="mb-8">
              <Shield className="h-4 w-4" />
              <div>
                <strong>Important Privacy Notice</strong>
                <p className="mt-1">
                  Xero Identity stores all user data on a public blockchain. This means your identity information 
                  is publicly accessible and permanent. Please read this policy carefully.
                </p>
              </div>
            </Alert>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">1. Information We Collect</h2>
              <div className="text-muted-foreground space-y-4">
                <h3 className="text-lg font-medium text-foreground">Identity Data</h3>
                <p>
                  When you use Xero Identity, you voluntarily provide identity information including:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Display name (required)</li>
                  <li>Email address (optional)</li>
                  <li>Website URL (optional)</li>
                  <li>Twitter username (optional)</li>
                </ul>
                
                <h3 className="text-lg font-medium text-foreground">Wallet Information</h3>
                <p>
                  We collect your wallet address when you connect to our service. This is necessary for 
                  blockchain interactions and identity management.
                </p>

                <h3 className="text-lg font-medium text-foreground">Usage Data</h3>
                <p>
                  We may collect basic usage analytics to improve our service, including page views, 
                  button clicks, and error logs. This data is anonymized and does not contain personal information.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">2. How We Use Information</h2>
              <div className="text-muted-foreground space-y-3">
                <p>We use the collected information for:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Storing your identity data on the blockchain as requested</li>
                  <li>Providing and maintaining our service</li>
                  <li>Improving user experience and functionality</li>
                  <li>Communicating with users about service updates</li>
                  <li>Debugging and troubleshooting technical issues</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">3. Public Nature of Blockchain Data</h2>
              <div className="text-muted-foreground space-y-4">
                <p>
                  <strong>All identity data you store through Xero Identity is public and permanent.</strong> 
                  This includes:
                </p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Your display name, email, website, and social media links</li>
                  <li>Your wallet address associated with the identity</li>
                  <li>Transaction history and timestamps of changes</li>
                  <li>All updates and modifications to your identity</li>
                </ul>
                <p>
                  Anyone with internet access can view this information on the blockchain. 
                  <strong> Only store information you are comfortable sharing publicly.</strong>
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">4. Data Sharing</h2>
              <div className="text-muted-foreground space-y-3">
                <p>
                  <strong>Blockchain Data:</strong> By design, all identity data stored on the blockchain 
                  is publicly accessible to anyone.
                </p>
                <p>
                  <strong>Analytics Data:</strong> We may share anonymized usage analytics with third-party 
                  analytics services to improve our platform.
                </p>
                <p>
                  <strong>Legal Requirements:</strong> We may disclose information if required by law or 
                  to protect our rights and safety.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">5. Data Retention and Deletion</h2>
              <div className="text-muted-foreground space-y-3">
                <p>
                  <strong>Blockchain Data:</strong> Due to the immutable nature of blockchain technology, 
                  identity data cannot be completely deleted once stored. You can update your information 
                  to empty values, but the transaction history remains permanent.
                </p>
                <p>
                  <strong>Website Data:</strong> Local storage and analytics data may be cleared by 
                  clearing your browser data or opting out of analytics tracking.
                </p>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">6. Security</h2>
              <p className="text-muted-foreground mb-4">
                We implement appropriate security measures to protect against unauthorized access, 
                alteration, disclosure, or destruction of your personal information. However, no method 
                of transmission over the internet is 100% secure.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">7. Your Rights and Choices</h2>
              <div className="text-muted-foreground space-y-3">
                <p>You have the right to:</p>
                <ul className="list-disc list-inside space-y-2 ml-4">
                  <li>Update your identity information at any time</li>
                  <li>Clear your identity data (sets fields to empty values)</li>
                  <li>Disconnect your wallet and stop using the service</li>
                  <li>Opt out of analytics tracking</li>
                  <li>Request information about what data we have collected</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">8. Children's Privacy</h2>
              <p className="text-muted-foreground mb-4">
                Our service is not intended for children under 13 years of age. We do not knowingly 
                collect personal information from children under 13. If you become aware that a child 
                has provided us with personal information, please contact us.
              </p>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-semibold text-foreground mb-4">9. Changes to This Policy</h2>
              <p className="text-muted-foreground mb-4">
                We may update our Privacy Policy from time to time. We will notify you of any changes 
                by posting the new Privacy Policy on this page and updating the "Last updated" date.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-foreground mb-4">10. Contact Us</h2>
              <p className="text-muted-foreground">
                If you have any questions about this Privacy Policy, please contact us through our 
                official communication channels or visit our documentation for more information.
              </p>
            </section>
          </div>
        </Card>
      </div>

      <Footer />
    </div>
  );
};